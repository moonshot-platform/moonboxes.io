export class Moonbox {
    type: string;
    currentSupply: number;
}