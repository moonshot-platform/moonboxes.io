import 'reflect-metadata';

export class UserDetailsModel {

    constructor(
        public address: number, 
        public balance: number,
    ){}
}