import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-join-application',
  templateUrl: './join-application.component.html',
  styleUrls: ['./join-application.component.scss']
})
export class JoinApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
