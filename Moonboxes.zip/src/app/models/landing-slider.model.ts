export class LandingSliderModel {
    constructor(
        public img: string,
        public name: string,
        public url: string
    ) {
    }
}